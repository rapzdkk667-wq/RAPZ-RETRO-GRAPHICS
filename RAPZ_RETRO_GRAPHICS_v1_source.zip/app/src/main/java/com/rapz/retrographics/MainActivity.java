package com.rapz.retrographics;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 10;
    private static final int CREATE_IMAGE = 11;
    private ImageView preview;
    private TextView amountLabel, status;
    private SeekBar pixelBar;
    private Bitmap original, output;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(18));
        root.setBackgroundColor(0xFF111111);

        TextView title = new TextView(this);
        title.setText("RAPZ RETRO GRAPHICS");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(23);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(8));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("MALI EDITION • OFFLINE PIXEL FILTER");
        subtitle.setTextColor(0xFFB9A5FF);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        preview = new ImageView(this);
        preview.setBackgroundColor(0xFF252525);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        imageParams.setMargins(0, dp(18), 0, dp(18));
        root.addView(preview, imageParams);

        amountLabel = new TextView(this);
        amountLabel.setTextColor(0xFFFFFFFF);
        amountLabel.setText("Pixel size: 6×");
        root.addView(amountLabel);

        pixelBar = new SeekBar(this);
        pixelBar.setMax(14);
        pixelBar.setProgress(4);
        root.addView(pixelBar);
        pixelBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                int scale = p + 2;
                amountLabel.setText("Pixel size: " + scale + "×");
                render(scale);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        Button open = new Button(this);
        open.setText("PILIH GAMBAR / SCREENSHOT");
        root.addView(open);
        open.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_IMAGE);
        });

        Button save = new Button(this);
        save.setText("SIMPAN HASIL");
        root.addView(save);
        save.setOnClickListener(v -> {
            if (output == null) {
                Toast.makeText(this, "Pilih gambar dulu", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/png");
            i.putExtra(Intent.EXTRA_TITLE, "RAPZ_RETRO.png");
            startActivityForResult(i, CREATE_IMAGE);
        });

        status = new TextView(this);
        status.setTextColor(0xFFAAAAAA);
        status.setTextSize(11);
        status.setText("Filter offline untuk gambar. Tidak mengubah Free Fire.");
        status.setPadding(0, dp(10), 0, 0);
        root.addView(status);
        setContentView(root);
    }

    private void render(int block) {
        if (original == null) return;
        int w = Math.max(1, original.getWidth() / block);
        int h = Math.max(1, original.getHeight() / block);
        Bitmap tiny = Bitmap.createScaledBitmap(original, w, h, false);
        output = Bitmap.createScaledBitmap(tiny, original.getWidth(), original.getHeight(), false);
        if (preview != null) preview.setImageBitmap(output);
        tiny.recycle();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == PICK_IMAGE) {
                InputStream in = getContentResolver().openInputStream(uri);
                original = BitmapFactory.decodeStream(in);
                if (in != null) in.close();
                if (original == null) throw new Exception("Gambar tidak bisa dibaca");
                render(pixelBar.getProgress() + 2);
                status.setText("Gambar dimuat. Geser Pixel Size untuk mengatur efek.");
            } else if (requestCode == CREATE_IMAGE && output != null) {
                OutputStream out = getContentResolver().openOutputStream(uri);
                output.compress(Bitmap.CompressFormat.PNG, 100, out);
                if (out != null) out.close();
                Toast.makeText(this, "Hasil tersimpan", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Gagal: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
